function phonenumber(inputtxt)
{
  var phoneno = /^\d{10}$/;
  if(phoneno.test(inputtxt))
  {
      return true;
  }
  else
  {	
	
     return false;
  }
  }

function validation(){
	
	var caller= document.forms["calls"]["caller"].value;
	var receiver = document.forms["calls"]["receiver"].value;
	var minutes = document.forms["calls"]["minutes"].value;
	var reg=/(([0-1][0-9])|([2][0-3])):([0-5][0-9]):([0-5][0-9])/;
	
	if (caller==null){
		Swal.fire({icon: 'error',title: 'Oops...',text:'Please input caller.'})
	    return false;
	}
	if (receiver==""){
		Swal.fire({icon: 'error',title: 'Oops...',text:'Please input receiver.'})
	    return false;
	}
	
	if (minutes==""){
		Swal.fire({icon: 'error',title: 'Oops...',text:'Please input duration of call.'})
	    return false;
	}
	
	if (phonenumber(receiver)==false)
	{
		Swal.fire({icon: 'error',title: 'Oops...',text:'Not a valid Phone Number.'});
		return false;
	}
	if (phonenumber(caller)==false)
	{
		Swal.fire({icon: 'error',title: 'Oops...',text:'Not a valid Phone Number.'});
		return false;
	}
	if (!(reg.test(minutes)))
	{     
		Swal.fire({icon: 'error',title: 'Oops...',text:'Not valid duration format. Please input HH:MM:SS where hours<24, minutes<59 and seconds<59.'})
		return false;
    }
	
}