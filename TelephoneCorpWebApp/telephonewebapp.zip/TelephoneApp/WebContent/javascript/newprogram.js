function validate(){
	var plan=document.forms["set1"]["program"].value;
	var min=document.forms["set1"]["minutes"].value;
	var cost=document.forms["set1"]["cost"].value;
	var reg = /^\d{5}$/;
	
	
	
	if (min=="" || min.length>5){
		Swal.fire({icon: 'error',title: 'Oops...',text:'Please enter a maximum 5 digit number.'});
		return false;
	}
	
	if (cost=="" || cost.length>2){
		Swal.fire({icon: 'error',title: 'Oops...',text:'Please enter a maximum 2 digit number.'});
		return false;
	}
}