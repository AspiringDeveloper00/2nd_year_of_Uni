function validation(){
	var x=document.forms["afmform"]["afm"].value;
	var reg = /^\d{9}$/;
	  if(reg.test(x))
	  {
	      return true;
	  }
	  else
	  {
		  Swal.fire({icon: 'error',title: 'Oops...',text:'Invalid afm, please enter a 9-digit afm number.'});
	     return false;
	  }
}