function validate(){
	var id=document.forms["set1"]["employeeid"].value;
	var sal=document.forms["set1"]["salary"].value;
	var reg = /^\d{6}$/;
	var reg2=!/\D/;
	
	if (!(reg.test(id))){
		Swal.fire({icon: 'error',title: 'Oops...',text:'Please enter a 6 digit number.'});
		return false;
	}
	
	if (sal=="" || sal.length>6){
		Swal.fire({icon: 'error',title: 'Oops...',text:'Please enter a maximum 6 digit number.'});
		return false;
	}
	
}

