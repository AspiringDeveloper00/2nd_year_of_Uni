package Model;

public class Users {
	//Setting the attributes of class Users
    private String Username;
	private String Name;
	private String Surname;
	private String Who;
	//Declaring UserCounter as static in order to be a class attribute and not an instance attribute
	public static int UserCounter=0;

	//Constructor of class Users
	public Users(){
		//Count the times that a user is created by class Users or a subclass (Client,Seller,Admin)
		UserCounter+=1;
	}
	//Creating method Register in order to save users' info 
	public void Register (String Username,String Name, String Surname,String Who) {
		this.Username=Username;
		this.Name=Name;
		this.Surname=Surname;
		this.Who=Who;
		System.out.println("Registration succesful!");
	}
	//Creating Login session
	public void Login() {
		System.out.println("Session established, you logged in!");
	}
	//Ending the session
	public void Logout() {
		System.out.println("You logged out succesfully");
	}
	
	public void setUsername(String Username) {
		this.Username=Username;
	    	
	}
	
	public void setName(String Name) {
		this.Name=Name;
	}
	
	public void setSurname(String Surname) {
		this.Surname=Surname;
	}
	
	public void setWho(String Who) {
		this.Who=Who;
	}
	
	public String getUsername() {
		return Username;
	}
	
	public String getName() {
		return Name;
	}
	
	public String getSurname() {
		return Surname;
	}
	
	public String getWho() {
		return Who;
	}
	
	
}
