package Model;

public class PhoneNumber {
	
	public String Number;
	public String NameProgram;
	
}

