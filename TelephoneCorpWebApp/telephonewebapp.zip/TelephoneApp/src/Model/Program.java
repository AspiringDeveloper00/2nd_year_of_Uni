package Model;

public class Program {
	private String NameProgram;
	private String MinutesOfTalk;
	private String Cost;
	
	public Program() {
		
	}
	
	public void setNameProgram(String NameProgram) {
		this.NameProgram=NameProgram;
	}
	public void setMinutesOfTalk(String MinutesOfTalk){
		this.MinutesOfTalk=MinutesOfTalk;
	}
	
	
	public void setCost(String Cost) {
		this.Cost=Cost;
	}
	 public String getCost() {
		 return Cost;
	 }
	public String getNameProgram() {
		return NameProgram;
	
	}
	public String getMinutesOfTalk() {
		return MinutesOfTalk;
		
	}
			
}