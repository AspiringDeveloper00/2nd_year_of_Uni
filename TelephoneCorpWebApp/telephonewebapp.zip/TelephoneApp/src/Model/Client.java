package Model;

import java.util.ArrayList;

public class Client extends Users{
    private String Afm=null;
	private PhoneNumber Phone;
	
	//Constructor of class Client
	public Client() {
		Phone=new PhoneNumber();
	}
	//Printing the bill info for a specific client 
	public void ShowBill() {
		
	}
	//Printing the call history of a specific client 
	public void ShowCallHistory() {
		
	}
	
	public void setAfm(String Afm) {
		this.Afm=Afm;
	}
	//Paying the bill 
	public void PayBill() {
		System.out.println("Bill has been paid!");
	}
	
	public String getAfm() {
		return Afm;
	}
	
	public void setPhonenumber(String Number) {
		this.Phone.Number=Number;

	}
	public void setProgram(String Program) {
		this.Phone.NameProgram=Program;

	}
	public String getPhone() {
		return this.Phone.Number;
	}
	public String getNameProgram() {
		return this.Phone.NameProgram;
	}
}

