package Model;

public class Admin extends Users{

	
	
	

}
