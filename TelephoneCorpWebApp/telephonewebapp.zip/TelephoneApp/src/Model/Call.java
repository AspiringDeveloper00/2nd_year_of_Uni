package Model;

public class Call {

	private String TimeStamp;
	private String Receiver;
	private String Caller;
	private String Minutes;
	
	public Call() {
			
	}
	public void setReceiver(String Receiver) {
		this.Receiver=Receiver;
	}
	
	public void setCaller(String Caller) {
		this.Caller=Caller;
	}
	public void setMinutes(String Minutes) {
		this.Minutes=Minutes;
	}
	
	public String getReceiver() {
		return Receiver;
	}
	public String getCaller() {
		return Caller;
	}
	public String getMinutes() {
		return Minutes;
	}
	public String getTimeStamp() {
		return TimeStamp;
	}
	public void setTimeStamp(String timeStamp) {
		TimeStamp = timeStamp;
	}
}
