package Model;

public class Seller extends Users {
	//Creating Sellers' attributes
	private String EmployeeId;
	private String Salary;
	
	public Seller() {
	
		
	}
	
	
	public void setEmployeeId(String EmployeeId) {
		this.EmployeeId=EmployeeId;
	}
	
	
	public void setSalary(String Salary) {
		this.Salary=Salary; 
	}
	
	public String getEmployeeId() {
		return EmployeeId;
	}
	
	
	public String getSalary() {
		return Salary;
	}
}
