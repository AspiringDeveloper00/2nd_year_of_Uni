package Model;

import java.util.ArrayList;

public class Bill extends PhoneNumber {
	private String Date;
	private PhoneNumber Phone;
	private String TotalCost;
	private String Status;
	
	
	public Bill() {
		Phone=new PhoneNumber();
		
	}
	
	
	public String getTotalCost() {
		return TotalCost;
	}
	
	public void setTotalCost(String TotalCost) {
		this.TotalCost=TotalCost;
	}
	
	public void setDate(String Date) {
		this.Date=Date;
	}
	public String getDate() {
		return Date;
	}
	
	public void setPhone(String Number) {
		this.Phone.Number=Number;
	}
	
	public void setNameProgram(String NameProgram) {
		this.Phone.NameProgram=NameProgram;
	}
	public String getPhone() {
		return Phone.Number;
	}
	public String getNameProgram() {
		return Phone.NameProgram;
	}


	public String getStatus() {
		return Status;
	}


	public void setStatus(String status) {
		Status = status;
	}
	
}
