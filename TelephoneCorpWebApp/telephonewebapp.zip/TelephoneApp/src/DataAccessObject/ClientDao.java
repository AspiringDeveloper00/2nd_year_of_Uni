package DataAccessObject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Model.Bill;
import Model.Call;
import Model.Client;
import Model.Program;
import Utilities.DbUtil;

public class ClientDao {

	private Connection connection;
		
	public ClientDao() {
        connection = DbUtil.getConnection();
    }
	
	public List Showbills(String username) {
		List<Bill> Bills = new ArrayList<Bill>();
		try {
			 PreparedStatement preparedStatement = connection.prepareStatement("select bills.date, bills.number, bills.name_program, bills.totalcost, bills.status from bills inner join clients on clients.number=bills.number where clients.username=? ");
			 preparedStatement.setString(1, username);
	         ResultSet rs = preparedStatement.executeQuery();         
	            while (rs.next()) {
	            	Bill Bill=new Bill();
	            	Bill.setDate(rs.getString("date"));
	            	Bill.setPhone(rs.getString("number"));
	            	Bill.setNameProgram(rs.getString("name_program"));
	            	Bill.setTotalCost(rs.getString("totalcost"));
	            	Bill.setStatus(rs.getString("status"));
	            	Bills.add(Bill);
	            }
		}catch (SQLException e) {
            e.printStackTrace();
        }
		return Bills;
	}
		
	public void Paybill(String date,String number) {
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("update bills set  status='settled' where date=? and number=?");
			preparedStatement.setString(1, date);
			preparedStatement.setString(2, number);
			preparedStatement.executeUpdate();
			
			
			}catch (SQLException e) {
				e.printStackTrace();
			}        
	}	
	
	public List Showbillspending(String username) {
		List<Bill> Bills = new ArrayList<Bill>();
		try {
			 PreparedStatement preparedStatement = connection.prepareStatement("select bills.date, bills.number, bills.name_program, bills.totalcost, bills.status from bills inner join clients on clients.number=bills.number where status='pending' and username=? ");
			 preparedStatement.setString(1, username);
	         ResultSet rs = preparedStatement.executeQuery();         
	            while (rs.next()) {
	            	Bill Bill=new Bill();
	            	Bill.setDate(rs.getString("date"));
	            	Bill.setPhone(rs.getString("number"));
	            	Bill.setNameProgram(rs.getString("name_program"));
	            	Bill.setTotalCost(rs.getString("totalcost"));
	            	Bill.setStatus(rs.getString("status"));
	            	Bills.add(Bill);
	            }
		}catch (SQLException e) {
            e.printStackTrace();
        }
		return Bills;
	}
	
	public String Getnumberbyusername (String username) {
		String number=null;
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("select number from clients where username=?");
			preparedStatement.setString(1, username);
			ResultSet rs = preparedStatement.executeQuery();
			if (rs.next()) {
				number=rs.getString("number");
			}
		}catch (SQLException e) {
            e.printStackTrace();
        }
		return number;
	}
	
	public String Checknumber(String number,String mynumber) {
		String answer = null;
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("select * from clients where number=? and number!=? ");
			preparedStatement.setString(1, number);		
			preparedStatement.setString(2, mynumber);	
			ResultSet rs = preparedStatement.executeQuery();  
			if (rs.next()==false) {
				answer="There is no user with that phone number.";
			}else {
				answer="ok";
			}
		
			}catch (SQLException e) {
				e.printStackTrace();
			}  
		return answer;
	}
	
	public void Addcall(Model.Call Call) 
	{
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("insert into calls (receiver,caller,timestamp,minutes) values(?,?,?,?)");
			preparedStatement.setString(1, Call.getReceiver());
			preparedStatement.setString(2, Call.getCaller());
			preparedStatement.setString(3, Call.getTimeStamp());
			preparedStatement.setString(4, Call.getMinutes());
			preparedStatement.executeUpdate();
			
		
			}catch (SQLException e) {
				e.printStackTrace();
			}        
	}
	
	public List Showallcalls(String caller) {
		List<Call> Calls = new ArrayList<Call>();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("select * from calls where caller=? or receiver=? ");
			preparedStatement.setString(1, caller);
			preparedStatement.setString(2, caller);	
	        ResultSet rs = preparedStatement.executeQuery();         
	        while (rs.next()) {
	        	Call Call=new Call();
	        	Call.setCaller(rs.getString("caller"));
	        	Call.setReceiver(rs.getString("receiver"));
	        	Call.setTimeStamp(rs.getString("timestamp"));
	        	Call.setMinutes(rs.getString("minutes"));
	        	Calls.add(Call);
	        	}
			}
	         catch (SQLException e) {
	            e.printStackTrace();
	        }        
		return Calls;
	}
	
	public String Checkafm(String username) {
		String answer=null;
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("select afm from clients where username=? ");
			preparedStatement.setString(1, username);
			ResultSet rs = preparedStatement.executeQuery();   
			if(rs.next()) {
				if (rs.getString("afm")!=null) {
				answer="ok";
				}else {
				answer="You have not entered your afm yet, please enter it.";
				}
			}
				
		} catch (SQLException e) {
            e.printStackTrace();
        }  
		return answer;
	}
	
	public String Checkafm2 (String afm) {
		String answer=null;
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("select * from clients where afm=? ");
			preparedStatement.setString(1, afm);
			ResultSet rs = preparedStatement.executeQuery(); 
			if (rs.next()) {
				answer="There is already a user with that afm.";
			}else {
				answer="ok";
			}
		}
		catch(SQLException e) {
            e.printStackTrace();
        }  
		return answer;
	}
	
	public void Insertafm(String username,String afm) {
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("update clients set afm=? where username=? ");
			preparedStatement.setString(1, afm);
			preparedStatement.setString(2, username);
			preparedStatement.executeUpdate();
			
		}
		catch(SQLException e) {
            e.printStackTrace();
        }  
	}
	
	public String Checkprogram (String user) {
		String answer=null;
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("select * from clients inner join  phonenumbers on clients.number=phonenumbers.number where phonenumbers.username=? and phonenumbers.name_program is null");
			preparedStatement.setString(1, user);
			ResultSet rs = preparedStatement.executeQuery(); 
			if (rs.next()) {
				answer="You have not entered a program yet,please enter it.";
			}else {
				answer="ok";
			}
		}
		catch(SQLException e) {
            e.printStackTrace();
        }  
		return answer;
	}
	
	public List Showallprograms() {
		List<Program> Programs = new ArrayList<Program>();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("select * from programs");
	        ResultSet rs = preparedStatement.executeQuery();         
	        while (rs.next()) {
	        	Program Program=new Program();
	        	Program.setNameProgram(rs.getString("name_program"));
	        	Program.setMinutesOfTalk(rs.getString("minutes_of_talk"));
	        	Program.setCost(rs.getString("Cost"));
	        	Programs.add(Program);
	        	}
			}
	         catch (SQLException e) {
	            e.printStackTrace();
	        }        
		return Programs;
	}
	
	public String Checknumber2 (String user) {
		String answer=null;
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("select * from clients where username=? and number is null and afm is not null");
			preparedStatement.setString(1, user);
			ResultSet rs = preparedStatement.executeQuery(); 
			if (rs.next()) {
				answer="A seller has not yet assigned you a number, please log in another time. Thank you for your patience and sorry for the inconvenience.";
			}else {
				answer="ok";
			}
		}
		catch(SQLException e) {
            e.printStackTrace();
        }  
		return answer;
	}
	
	public void Setprogram(String username,String program) 
	{
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("update phonenumbers set name_program=? where username=? ");
			preparedStatement.setString(1, program);
			preparedStatement.setString(2, username);
			preparedStatement.executeUpdate();
			
		}
		catch(SQLException e) {
            e.printStackTrace();
        }  
	}
}
