package DataAccessObject;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;



import Utilities.DbUtil;



public class SystemDao {

	private Connection connection;
	
	public SystemDao() {
        connection = DbUtil.getConnection();
    }
	
	
	public String bytesToHex(byte[] hash) {
	    StringBuffer hexString = new StringBuffer();
	    for (int i = 0; i < hash.length; i++) {
	    String hex = Integer.toHexString(0xff & hash[i]);
	    if(hex.length() == 1) hexString.append('0');
	        hexString.append(hex);
	    }
	    return hexString.toString();
	}
	
	public String getAlphaNumericString(int n) 
    { 
  
        // chose a Character random from this String 
        String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                                    + "0123456789"
                                    + "abcdefghijklmnopqrstuvxyz"; 
  
        // create StringBuffer size of AlphaNumericString 
        StringBuilder sb = new StringBuilder(n); 
  
        for (int i = 0; i < n; i++) { 
  
            // generate a random number between 
            // 0 to AlphaNumericString variable length 
            int index 
                = (int)(AlphaNumericString.length() 
                        * Math.random()); 
  
            // add Character one by one in end of sb 
            sb.append(AlphaNumericString 
                          .charAt(index)); 
        } 
  
        return sb.toString(); 
    } 
	
	public String getSalt(String username) {
		String salt=null;
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("select salt from userslogininfo where username=?");
            preparedStatement.setString(1, username);
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) 
            { 
            	salt=rs.getString("salt");
        	} 
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return salt;
	}
	
	public String loginusernameCheck(String username) {
		String answer=null;
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("select * from userslogininfo where username=?");
            preparedStatement.setString(1, username);
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next() == false) 
            { 
            	 answer="There is no user with the username: "+username+", please enter a valid username!";
        	} 
            else 
            { 
            	answer=username;
        	}

            

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return answer;
    }
	
	
	public String passwordCheck(String username,String password) {
		String answer=null;
		try {
            	PreparedStatement preparedStatement = connection.prepareStatement("select * from userslogininfo where (username=? and password=?)");
            	preparedStatement.setString(1, username);
            	preparedStatement.setString(2, password);
            	ResultSet rs = preparedStatement.executeQuery();
            	if (rs.next() == false) 
            	{ 
            		answer="Wrong Password!";
            	} 
            	else 
            	{ 
            		answer="You logged in!";
            	}

        	} catch (SQLException e) {
            e.printStackTrace();
        	}
        return answer;
	}
	
	
	public String signupusernameCheck(String username) {
		String answer=null;
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("select * from userslogininfo where username=?");
            preparedStatement.setString(1, username);
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next() == false) 
            { 
            	 answer="ok";
        	} 
            else 
            { 
            	answer="There is already a user with the username: "+username+", please enter a different username.";
        	}
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return answer;
    }
	
	
	public void signup(String username, String name, String surname, String who, String password, String salt ) 
	{
		try {
			
			if(who.equals("seller")) 
			{
				PreparedStatement preparedStatement = connection.prepareStatement("insert into sellers (username,name,surname,who,employeeid,salary) values (?,?,?,?,?,?)");
				preparedStatement.setString(1, username);
				preparedStatement.setString(2, name);
				preparedStatement.setString(3, surname);
				preparedStatement.setString(4, who);
				preparedStatement.setString(5, null);
				preparedStatement.setString(6, null);
				preparedStatement.executeUpdate();
				
				PreparedStatement preparedStatement1 = connection.prepareStatement("insert into userslogininfo (username,password,salt) values (?,?,?)");
				preparedStatement1.setString(1, username);
				preparedStatement1.setString(2, password);
				preparedStatement1.setString(3, salt);
				preparedStatement1.executeUpdate();
			
			}
			else if (who.equals("admin"))
			{
				PreparedStatement preparedStatement = connection.prepareStatement("insert into admins (username,name,surname,who) values (?,?,?,?)");
				preparedStatement.setString(1, username);
				preparedStatement.setString(2, name);
				preparedStatement.setString(3, surname);
				preparedStatement.setString(4, who);
				preparedStatement.executeUpdate();
			
				PreparedStatement preparedStatement1 = connection.prepareStatement("insert into userslogininfo (username,password,salt) values (?,?,?)");
				preparedStatement1.setString(1, username);
				preparedStatement1.setString(2, password);
				preparedStatement1.setString(3, salt);
				preparedStatement1.executeUpdate();
			}
			else  
			{
				PreparedStatement preparedStatement = connection.prepareStatement("insert into clients (username,name,surname,who,afm,number) values (?,?,?,?,?,?)");
				preparedStatement.setString(1, username);
				preparedStatement.setString(2, name);
				preparedStatement.setString(3, surname);
				preparedStatement.setString(4, who);
				preparedStatement.setString(5, null);
				preparedStatement.setString(6, null);
				preparedStatement.executeUpdate();
			
				PreparedStatement preparedStatement1 = connection.prepareStatement("insert into phonenumbers (username,number,name_program) values (?,?,?)");
				preparedStatement1.setString(1, username);
				preparedStatement1.setString(2, null);
				preparedStatement1.setString(3, null);
				preparedStatement1.executeUpdate();
				
				PreparedStatement preparedStatement2 = connection.prepareStatement("insert into userslogininfo (username,password,salt) values (?,?,?)");
				preparedStatement2.setString(1, username);
				preparedStatement2.setString(2, password);
				preparedStatement2.setString(3, salt);
				preparedStatement2.executeUpdate();
			}
			
		}catch(SQLException e) {
            e.printStackTrace();
        }		
	}
	
	
	public String getWho(String username) {
		String who=null;
		try {
            PreparedStatement preparedStatement = connection.prepareStatement("select * from clients where username=?");
            preparedStatement.setString(1, username);
            ResultSet rs1 = preparedStatement.executeQuery();
            if (rs1.next() == true) 
            { 
            	 who="client";
            	 
        	} 
            else 
        	{
        		preparedStatement = connection.prepareStatement("select * from sellers where username=?");
        		preparedStatement.setString(1, username);
        		ResultSet rs2 = preparedStatement.executeQuery();
        		
        		if (rs2.next() == true) 
                { 
                	 who="seller";
                	 
            	} 
        		else 
            	{
            		 preparedStatement = connection.prepareStatement("select * from admins where username=?");
            		 preparedStatement.setString(1, username);
            		 ResultSet rs3 = preparedStatement.executeQuery();
            		 if (rs3.next() == true) 
                     { 
                     	 who="admin";
                     	 
                 	 }
            		 
            	}
           
        	}
                
        } catch (SQLException e) {
            e.printStackTrace();
        }
		return who;
	}
}
