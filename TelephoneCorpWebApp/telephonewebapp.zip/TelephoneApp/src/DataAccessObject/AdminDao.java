package DataAccessObject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Model.Client;
import Model.Program;
import Model.Seller;
import Utilities.DbUtil;

public class AdminDao {
private Connection connection;
	
	public AdminDao() {
        connection = DbUtil.getConnection();
    }
	
	public List Showallsellers() {
		List<Seller> Sellers = new ArrayList<Seller>();
		try {
            PreparedStatement preparedStatement = connection.prepareStatement("select * from sellers");
            ResultSet rs = preparedStatement.executeQuery();         
            while (rs.next()) {
            	Seller Seller=new Seller();
            	Seller.setUsername(rs.getString("username"));
            	Seller.setName(rs.getString("name"));
            	Seller.setSurname(rs.getString("surname"));
            	Seller.setEmployeeId(rs.getString("employeeid")); 
            	Seller.setSalary(rs.getString("salary"));
            	Sellers.add(Seller);
            }
            } catch (SQLException e) {
                e.printStackTrace();
            }

		return Sellers;
	}
	
	public void Deleteseller(String username) {
		try {
			 PreparedStatement preparedStatement = connection.prepareStatement("delete from sellers where username=?");
			 preparedStatement.setString(1, username);
			 preparedStatement.executeUpdate();
			 
			 PreparedStatement preparedStatement1 = connection.prepareStatement("delete from userslogininfo where username=?");
			 preparedStatement1.setString(1, username);
			 preparedStatement1.executeUpdate();
			
		}catch (SQLException e) {
            e.printStackTrace();
        }
	}
	
	public List Showclients() {
		List<Client> Clients = new ArrayList<Client>();
		try {
            PreparedStatement preparedStatement = connection.prepareStatement("select clients.username,clients.name,clients.surname,clients.afm,clients.number, phonenumbers.name_program from clients inner join phonenumbers on clients.username=phonenumbers.username");
            ResultSet rs = preparedStatement.executeQuery();         
            while (rs.next()) {
            	Client Client=new Client();
            	Client.setUsername(rs.getString("username"));
            	Client.setName(rs.getString("name"));
            	Client.setSurname(rs.getString("surname"));
            	Client.setAfm(rs.getString("afm")); 
            	Client.setPhonenumber(rs.getString("number"));
            	Client.setProgram( rs.getString("name_program"));
            	Clients.add(Client);
            }
            } catch (SQLException e) {
                e.printStackTrace();
            }

		return Clients;
	}
	
	public void Deleteclient(String username,String number) {
		try {
			 PreparedStatement preparedStatement = connection.prepareStatement("delete from clients where username=?");
			 preparedStatement.setString(1, username);
			 preparedStatement.executeUpdate();
			 
			 PreparedStatement preparedStatement1 = connection.prepareStatement("delete from userslogininfo where username=?");
			 preparedStatement1.setString(1, username);
			 preparedStatement1.executeUpdate();
			 

			 PreparedStatement preparedStatement2 = connection.prepareStatement("delete from phonenumbers where number=?");
			 preparedStatement2.setString(1, number);
			 preparedStatement2.executeUpdate();
			 
			 PreparedStatement preparedStatement3 = connection.prepareStatement("delete from bills where number=?");
			 preparedStatement3.setString(1, number);
			 preparedStatement3.executeUpdate();
			 
			 PreparedStatement preparedStatement4 = connection.prepareStatement("delete from calls where caller=? or receiver=?");
			 preparedStatement4.setString(1, number);
			 preparedStatement4.setString(2, number);
			 preparedStatement4.executeUpdate();
			
		}catch (SQLException e) {
            e.printStackTrace();
        }
	}
	
	public List Showsellers() {
		List<Seller> Sellers = new ArrayList<Seller>();
		try {
            PreparedStatement preparedStatement = connection.prepareStatement("select * from sellers where employeeid is null and salary is null");
            ResultSet rs = preparedStatement.executeQuery();         
            while (rs.next()) {
            	Seller Seller=new Seller();
            	Seller.setUsername(rs.getString("username"));
            	Seller.setName(rs.getString("name"));
            	Seller.setSurname(rs.getString("surname"));
            	Seller.setEmployeeId(rs.getString("employeeid")); 
            	Seller.setSalary(rs.getString("salary"));
            	Sellers.add(Seller);
            }
            } catch (SQLException e) {
                e.printStackTrace();
            }

		return Sellers;
	}
	
	public Seller Getsellerbyusername(String username) {
		Seller Seller=new Seller();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("select * from sellers where username=?");
			preparedStatement.setString(1, username);
			ResultSet rs = preparedStatement.executeQuery();
			if(rs.next()) {
				Seller.setUsername(rs.getString("username"));
				Seller.setName(rs.getString("name"));
				Seller.setSurname(rs.getString("surname"));
				Seller.setEmployeeId(rs.getString("employeeid")); 
				Seller.setSalary(rs.getString("salary"));           	
			}
		}catch (SQLException e) {
            e.printStackTrace();
        }
		return Seller;
	}
	
	public String Checkemployeeid(String id) {
		String answer=null;
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("select * from sellers where employeeid=?");
			preparedStatement.setString(1, id);
			ResultSet rs = preparedStatement.executeQuery();
			if(rs.next()) {
				answer="There is already a seller with that Employee Id.";	
			}else 
			{
				answer="ok";
			}
		}catch (SQLException e) {
            e.printStackTrace();
        }
		return answer;
	}
	
	public void Updateseller(Seller Seller) {
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("update sellers set employeeid=?,salary=? where username=?");
			preparedStatement.setString(1, Seller.getEmployeeId());
			preparedStatement.setString(2, Seller.getSalary());
			preparedStatement.setString(3, Seller.getUsername());
			preparedStatement.executeUpdate();
			}catch (SQLException e) {
				e.printStackTrace();
			}        
	}
	
	public String Checkprogram(String program) {
		String answer=null;
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("select * from programs where name_program=?");
			preparedStatement.setString(1, program);
			ResultSet rs = preparedStatement.executeQuery();
			if(rs.next()) {
				answer="There is already a program with that name.";	
			}else 
			{
				answer="ok";
			}
		}catch (SQLException e) {
            e.printStackTrace();
        }
		return answer;
	}
	
	
	public void Insertprograms(Program Program) {
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("insert into programs (name_program,minutes_of_talk,cost) values (?,?,?)");
			preparedStatement.setString(1,Program.getNameProgram());
			preparedStatement.setString(2, Program.getMinutesOfTalk());
			preparedStatement.setString(3, Program.getCost());
			preparedStatement.executeUpdate();
			}catch (SQLException e) {
				e.printStackTrace();
			}        
	}
	
	public List Showallprograms() {
		List<Program> Programs = new ArrayList<Program>();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("select * from programs");
	        ResultSet rs = preparedStatement.executeQuery();         
	        while (rs.next()) {
	        	Program Program=new Program();
	        	Program.setNameProgram(rs.getString("name_program"));
	        	Program.setMinutesOfTalk(rs.getString("minutes_of_talk"));
	        	Program.setCost(rs.getString("Cost"));
	        	Programs.add(Program);
	        	}
			}
	         catch (SQLException e) {
	            e.printStackTrace();
	        }        
		return Programs;
	}
	
}
