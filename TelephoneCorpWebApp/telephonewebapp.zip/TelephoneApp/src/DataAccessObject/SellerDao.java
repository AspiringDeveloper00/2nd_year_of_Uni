package DataAccessObject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import Model.Bill;
import Model.Client;
import Model.Program;
import Utilities.DbUtil;

public class SellerDao {

	private Connection connection;
	
	public SellerDao() {
        connection = DbUtil.getConnection();
    }
	
	public List Showclients() {
		List<Client> Clients = new ArrayList<Client>();
		try {
            PreparedStatement preparedStatement = connection.prepareStatement("select clients.username,clients.name,clients.surname,clients.afm,clients.number, phonenumbers.name_program from clients inner join phonenumbers on clients.username=phonenumbers.username where clients.number is null and clients.afm is not null");
            ResultSet rs = preparedStatement.executeQuery();         
            while (rs.next()) {
            	Client Client=new Client();
            	Client.setUsername(rs.getString("username"));
            	Client.setName(rs.getString("name"));
            	Client.setSurname(rs.getString("surname"));
            	Client.setAfm(rs.getString("afm")); 
            	Client.setPhonenumber(rs.getString("number"));
            	Client.setProgram( rs.getString("name_program"));
            	Clients.add(Client);
            }
            } catch (SQLException e) {
                e.printStackTrace();
            }

		return Clients;
	}
	
	public Client Getclientbyusername(String username) {
		Client Client=new Client();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("select clients.username,clients.name,clients.surname,clients.afm,clients.number, phonenumbers.name_program from clients inner join phonenumbers on clients.username=phonenumbers.username where clients.username=?");
			preparedStatement.setString(1, username);
			ResultSet rs = preparedStatement.executeQuery();
			if(rs.next()) {
				Client.setUsername(rs.getString("username"));
            	Client.setName(rs.getString("name"));
            	Client.setSurname(rs.getString("surname"));
            	Client.setAfm(rs.getString("afm")); 
            	Client.setPhonenumber(rs.getString("number"));
            	Client.setProgram(rs.getString("name_program"));
			}
		}catch (SQLException e) {
            e.printStackTrace();
        }
		return Client;
	}
	
	public List Showallclients() {
		List<Client> Clients = new ArrayList<Client>();
		try {
		PreparedStatement preparedStatement = connection.prepareStatement("select clients.username,clients.name,clients.surname,clients.afm,clients.number, phonenumbers.name_program from clients inner join phonenumbers on clients.username=phonenumbers.username where clients.number is not null and clients.afm is not null and phonenumbers.name_program is not null ");
        ResultSet rs = preparedStatement.executeQuery();         
        while (rs.next()) {
        	Client Client=new Client();
        	Client.setUsername(rs.getString("username"));
        	Client.setName(rs.getString("name"));
        	Client.setSurname(rs.getString("surname"));
        	Client.setAfm(rs.getString("afm")); 
        	Client.setPhonenumber(rs.getString("number"));
        	Client.setProgram( rs.getString("name_program"));
        	Clients.add(Client);
        	}
		}
         catch (SQLException e) {
            e.printStackTrace();
        }        
	return Clients;
	}
	
	public List Showallprograms() {
		List<Program> Programs = new ArrayList<Program>();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("select * from programs");
	        ResultSet rs = preparedStatement.executeQuery();         
	        while (rs.next()) {
	        	Program Program=new Program();
	        	Program.setNameProgram(rs.getString("name_program"));
	        	Program.setMinutesOfTalk(rs.getString("minutes_of_talk"));
	        	Program.setCost(rs.getString("Cost"));
	        	Programs.add(Program);
	        	}
			}
	         catch (SQLException e) {
	            e.printStackTrace();
	        }        
		return Programs;
	}
	
	public void Updateclient (Client Client) {
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("update clients set  number=? where username=?");
			preparedStatement.setString(1, Client.getPhone());
			preparedStatement.setString(2, Client.getUsername());
			preparedStatement.executeUpdate();
			
			PreparedStatement preparedStatement1 = connection.prepareStatement("update phonenumbers set  number=? where username=?");
			preparedStatement1.setString(1, Client.getPhone());
			preparedStatement1.setString(2, Client.getUsername());
			preparedStatement1.executeUpdate();
			
			}catch (SQLException e) {
				e.printStackTrace();
			}        
	}
	
	public void Insertbill (Bill Bill) {
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("insert into bills (date,number,name_program,totalcost,status) values(?,?,?,?,?)");
			preparedStatement.setString(1, Bill.getDate());
			preparedStatement.setString(2, Bill.getPhone());
			preparedStatement.setString(3, Bill.getNameProgram());
			preparedStatement.setString(4, Bill.getTotalCost());
			preparedStatement.setString(5, Bill.getStatus());
			preparedStatement.executeUpdate();
			
		
			}catch (SQLException e) {
				e.printStackTrace();
			}        
	}
	
	public String Gettotalcost(String program) {
		String Totalcost ="0";
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("select cost from programs where name_program=? ");
			preparedStatement.setString(1, program);			
			ResultSet rs = preparedStatement.executeQuery();  
			if (rs.next()) {
				Totalcost=rs.getString("cost");
			}
		
			}catch (SQLException e) {
				e.printStackTrace();
			}        
		return Totalcost;
	}
	
	public String Checknumber(String number) {
		String answer = null;
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("select * from clients where number=? ");
			preparedStatement.setString(1, number);			
			ResultSet rs = preparedStatement.executeQuery();  
			if (rs.next()==false) {
				answer="ok";
			}else {
				answer="There is already a user with that phone number.";
			}
		
			}catch (SQLException e) {
				e.printStackTrace();
			}  
		return answer;
	}
	 public String Checkbill(String number,String date) {
		 String answer = null; 
		 try {
				PreparedStatement preparedStatement = connection.prepareStatement("select date from bills where number=? and date=? ");
				preparedStatement.setString(1, number);	
				preparedStatement.setString(2, date);	
				ResultSet rs = preparedStatement.executeQuery(); 				
				if (rs.next()==false) {
					answer="ok";
				}else {
					answer="There is already a bill during that month and year.";
				}
			
				}catch (SQLException e) {
					e.printStackTrace();
				}  
		 return answer;
	 }
	 
	 public void Changeprogram(String username, String program) 
	 {
		 try {
				PreparedStatement preparedStatement = connection.prepareStatement("update phonenumbers set name_program=? where username=?");
				preparedStatement.setString(1, program);
				preparedStatement.setString(2, username);
				preparedStatement.executeUpdate();
			}catch (SQLException e) {
				e.printStackTrace();
			}        
	 }
	 
	 public String Checkid(String username) {
			String answer = null;
			try {
				PreparedStatement preparedStatement = connection.prepareStatement("select employeeid,Salary from sellers where username=? ");
				preparedStatement.setString(1, username);			
				ResultSet rs = preparedStatement.executeQuery();  
				if (rs.next()) {
					if (rs.getString("employeeid")==null||rs.getString("Salary")==null) {
					answer="An admin has not yet assigned you an EmpolyeeId and a Salary, please log in another time!";
					}
					else 
					{
						answer="ok";
					}
				}
			
				}catch (SQLException e) {
					e.printStackTrace();
				}  
			return answer;
		}
}
