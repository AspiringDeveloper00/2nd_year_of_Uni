package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.util.*;

import DataAccessObject.*;
import Utilities.*;
import Model.*;


@WebServlet("/seller")
public class SellerController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private SellerDao dao;  
    
    
    public SellerController() {
        super();
        dao=new SellerDao();
    }

	
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");

		if(action.equalsIgnoreCase("add")) {
			List<Client> Clients = new ArrayList<Client>();
			Clients=dao.Showclients();
			request.setAttribute("list",Clients );
			request.setAttribute("action","add");
			RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/seller.jsp");
			requestDispatcher.forward(request,response);
		}else if (action.equalsIgnoreCase("edit")) {
			Client Client=dao.Getclientbyusername(request.getParameter("username"));
			request.setAttribute("user",Client.getUsername() );
			request.setAttribute("name",Client.getName() );
			request.setAttribute("surname",Client.getSurname() );
			request.setAttribute("afm",Client.getAfm() );
			request.setAttribute("number",Client.getPhone() );
			request.setAttribute("program",Client.getNameProgram() );
			RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/editseller.jsp");
			requestDispatcher.forward(request,response);
		}else if (action.equalsIgnoreCase("showclients")) {
			List<Client> Clients = new ArrayList<Client>();
			Clients=dao.Showallclients();
			request.setAttribute("list",Clients );
			request.setAttribute("action","showclients");
			RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/seller.jsp");
			requestDispatcher.forward(request,response);
		}else if (action.equalsIgnoreCase("showprograms")) {
			List<Program> Programs = new ArrayList<Program>();
			Programs=dao.Showallprograms();
			request.setAttribute("list",Programs );
			request.setAttribute("action","showprograms");
			RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/seller.jsp");
			requestDispatcher.forward(request,response);
		}else if (action.equalsIgnoreCase("inst")) {
			request.setAttribute("action","inst");
			RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/seller.jsp");
			requestDispatcher.forward(request,response);
		}else if (action.equalsIgnoreCase("setbill")) {
			List<Client> Clients = new ArrayList<Client>();
			Clients=dao.Showallclients();
			request.setAttribute("list",Clients );
			request.setAttribute("action","setbill");
			RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/seller.jsp");
			requestDispatcher.forward(request,response);
		}else if (action.equalsIgnoreCase("setbilldirect")) {
			Client Client=dao.Getclientbyusername(request.getParameter("username"));
			request.setAttribute("number",Client.getPhone() );
			request.setAttribute("user", request.getParameter("username"));
			request.setAttribute("program",Client.getNameProgram());
			RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/setbill.jsp");
			requestDispatcher.forward(request,response);
		}else if (action.equalsIgnoreCase("changeprogram")) {
			List<Client> Clients = new ArrayList<Client>();
			Clients=dao.Showallclients();
			request.setAttribute("list",Clients );
			request.setAttribute("action","changeprogram");
			RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/seller.jsp");
			requestDispatcher.forward(request,response);
		}
		else if (action.equalsIgnoreCase("changeprogram2")) 
		{
			List<Program> Programs = new ArrayList<Program>();
			Programs=dao.Showallprograms();
			request.setAttribute("list",Programs );
			request.setAttribute("user",request.getParameter("username") );
			request.setAttribute("action","changeprogram2");
			RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/seller.jsp");
			requestDispatcher.forward(request,response);
		}else if (action.equalsIgnoreCase("change")) 
		{
			dao.Changeprogram(request.getParameter("username"),request.getParameter("program"));
			List<Client> Clients = new ArrayList<Client>();
			Clients=dao.Showallclients();
			request.setAttribute("list",Clients );
			request.setAttribute("action","changeprogram");
			RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/seller.jsp");
			requestDispatcher.forward(request,response);
		}
		
			
	
	}
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String action = request.getParameter("action");
		String id=(String) request.getAttribute("action");
		
		HttpSession session=request.getSession(false);
		String user=(String) session.getAttribute("username");
		
		if (action!=null) {
		if (action.equalsIgnoreCase("editclient"))
		{
			String username=request.getParameter("username");
			String name=request.getParameter("name");
			String surname=request.getParameter("surname");
			String afm=request.getParameter("afm");
			String program=request.getParameter("program");
			String number=request.getParameter("number");
			
			String answer=dao.Checknumber(number);
			
			if (answer=="ok") {
			
			Client Client=new Client();
			Client.setUsername(username);
			Client.setPhonenumber(number);
			dao.Updateclient(Client);
			List<Client> Clients = new ArrayList<Client>();
			Clients=dao.Showclients();
			request.setAttribute("list", Clients);
			request.setAttribute("action","add");
			RequestDispatcher view = request.getRequestDispatcher("/seller.jsp");
			view.forward(request, response);
	
			}
			else 
			{
				request.setAttribute("answer",answer);
				request.setAttribute("user",username);
				request.setAttribute("name",name);
				request.setAttribute("surname",surname);
				request.setAttribute("afm",afm);
				request.setAttribute("program",program);
				RequestDispatcher view = request.getRequestDispatcher("/editseller.jsp");
				view.forward(request, response);
			}
		}else if (action.equalsIgnoreCase("set")){
			
			String username=request.getParameter("username");
			String program=request.getParameter("program");
			String number=request.getParameter("number");
			String date=request.getParameter("date");
			
			String answer=dao.Checkbill(number,date);
			
			if (answer=="ok") {
				Bill Bill=new Bill();
				Bill.setDate(date);
				Bill.setPhone(number);
				Bill.setNameProgram(program);
				Bill.setStatus("pending");
				Bill.setTotalCost(dao.Gettotalcost(program));
				dao.Insertbill(Bill);
				List<Client> Clients = new ArrayList<Client>();
				Clients=dao.Showallclients();
				request.setAttribute("list",Clients );
				request.setAttribute("action","setbill");
				RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/seller.jsp");
				requestDispatcher.forward(request,response);
			}
			else if (answer=="There is already a bill during that month and year.")
			{
				request.setAttribute("answer",answer);
				request.setAttribute("user",username);
				request.setAttribute("program",program);
				request.setAttribute("number",number);
				RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/setbill.jsp");
				requestDispatcher.forward(request,response);
			}
		}
		}
		if (id=="id") 
		{
			String answer=dao.Checkid(user);
			if(answer=="An admin has not yet assigned you an EmpolyeeId and a Salary, please log in another time!") {
				System.out.println(answer);
				request.setAttribute("answer",answer);
				request.setAttribute("action","");
				RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/index.jsp");
				requestDispatcher.forward(request,response);
			}else 
			{
				request.setAttribute("action", "");
				RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/seller.jsp");
				requestDispatcher.forward(request,response);
			}
		}
		
	}
}



