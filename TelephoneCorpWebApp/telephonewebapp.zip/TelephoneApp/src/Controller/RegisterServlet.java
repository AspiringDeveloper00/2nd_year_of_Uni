package Controller;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DataAccessObject.SystemDao;



@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private SystemDao dao;
       
    
    public RegisterServlet() {
        super();
        dao=new SystemDao();
    }

    
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String salt=dao.getAlphaNumericString(16);
		String username=request.getParameter("newusername");
		String name=request.getParameter("newname");
		String surname=request.getParameter("newsurname");
		String password=request.getParameter("newpassword1")+salt;
		String who=request.getParameter("who");
		String usernamevalidation=dao.signupusernameCheck(username);
		if (usernamevalidation=="ok") 
		{
			MessageDigest digest;
			try {
					digest = MessageDigest.getInstance("SHA-256");
					byte[] encodedhash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
					password=dao.bytesToHex(encodedhash);
					dao.signup(username, name, surname, who, password,salt);
					HttpSession session = request.getSession();
					synchronized(session) 
					{
						
						session.setAttribute("username", username);
						session.setAttribute("name",name);
						session.setAttribute("surname", surname);

						if (who.equals("admin")) 
						{
							session.setAttribute("who", "admin");
							RequestDispatcher view = request.getRequestDispatcher("/admin.jsp");
							view.forward(request, response);
						}
						else if (who.equals("client")) 
						{
							session.setAttribute("who", "client");
							request.setAttribute("action","afm");
							RequestDispatcher dispatcher =request.getRequestDispatcher("client");
							dispatcher.forward(request, response);
						}
						else 
						{
							session.setAttribute("who", "seller");
							request.setAttribute("action","id");
							RequestDispatcher view = request.getRequestDispatcher("seller");
							view.forward(request, response);
						}
					}	
				}
			catch (NoSuchAlgorithmException e) 
					{
						e.printStackTrace();
					}
		}
		else 
		{
			request.setAttribute("message", usernamevalidation);
			request.setAttribute("user", username);
			RequestDispatcher view = request.getRequestDispatcher("/index.jsp");
			view.forward(request, response);
		}	
	}
}
