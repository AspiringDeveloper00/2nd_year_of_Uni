package Controller;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;



import DataAccessObject.SystemDao;
import Controller.*;


@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private SystemDao dao;
	
	public LoginServlet() {
	        super();
	        dao=new SystemDao();
	    }
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		String usernamevalidation=dao.loginusernameCheck(username);
		if (usernamevalidation!=username) 
		{
			request.setAttribute("message", usernamevalidation);
			request.setAttribute("user", username);
			RequestDispatcher view = request.getRequestDispatcher("/index.jsp");
			view.forward(request, response);
		}else 
		{
			password=password+dao.getSalt(username);
			MessageDigest digest;
			try {
					digest = MessageDigest.getInstance("SHA-256");
					byte[] encodedhash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
					password=dao.bytesToHex(encodedhash);
					String passwordvalidation=dao.passwordCheck(username, password);
					if (passwordvalidation=="You logged in!") 
					{
						String who=dao.getWho(username);
						HttpSession session = request.getSession();
						synchronized(session) 
						{	
							session.setAttribute("username", username);
							
							if (who.equals("admin")) 
							{
								session.setAttribute("who", "admin");
								RequestDispatcher view = request.getRequestDispatcher("/admin.jsp");
								view.forward(request, response);
							}
							else if (who.equals("client")) 
							{
								session.setAttribute("who", "client");
								request.setAttribute("action","afm");
								RequestDispatcher dispatcher =request.getRequestDispatcher("client");
								dispatcher.forward(request, response);
							
							}
							else 
							{
								session.setAttribute("who", "seller");
								request.setAttribute("action","id");
								RequestDispatcher view = request.getRequestDispatcher("seller");
								view.forward(request, response);
							}
						}	
						
					}
					else 
					{
						request.setAttribute("message", passwordvalidation);
						RequestDispatcher view = request.getRequestDispatcher("/index.jsp");
						view.forward(request, response);
					}
				} 
				catch (NoSuchAlgorithmException e) 
				{
					e.printStackTrace();
				}
		}	
	}
}
