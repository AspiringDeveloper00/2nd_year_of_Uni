package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.util.*;

import DataAccessObject.*;
import Utilities.*;
import Model.*;


@WebServlet("/client")
public class ClientController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private ClientDao dao;   
   
    
    public ClientController() {
        super();
        dao=new ClientDao();
    }

	
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		HttpSession session=request.getSession(false);
		String user=(String) session.getAttribute("username");
		
		if(action.equalsIgnoreCase("showbills")) {
			List<Bill> Bills = new ArrayList<Bill>();
			Bills=dao.Showbills(user);
			request.setAttribute("list",Bills );
			request.setAttribute("action","showbills");
			RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/client.jsp");
			requestDispatcher.forward(request,response);
		}else if (action.equalsIgnoreCase("pay")) {	
			List<Bill> Bills = new ArrayList<Bill>();
			Bills=dao.Showbillspending(user);
			request.setAttribute("list",Bills );
			request.setAttribute("action","paybill");
			RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/client.jsp");
			requestDispatcher.forward(request,response);
		}else if (action.equalsIgnoreCase("payit")) {
			dao.Paybill(request.getParameter("date"),request.getParameter("number"));
			List<Bill> Bills = new ArrayList<Bill>();
			Bills=dao.Showbillspending(user);
			request.setAttribute("list",Bills );
			request.setAttribute("action","paybill");
			RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/client.jsp");
			requestDispatcher.forward(request,response);
		}else if (action.equalsIgnoreCase("makecall")) {
			String number=dao.Getnumberbyusername(user);
			request.setAttribute("number",number);
			RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/makecall.jsp");
			requestDispatcher.forward(request,response);
		}else if (action.equalsIgnoreCase("showcalls")) {
			List<Call> Calls = new ArrayList<Call>();
			String number=dao.Getnumberbyusername(user);
			Calls=dao.Showallcalls(number);
			request.setAttribute("list", Calls);
			request.setAttribute("action","showcalls");
			RequestDispatcher view = request.getRequestDispatcher("/client.jsp");
			view.forward(request, response);
		}else if(action.equalsIgnoreCase("inst")) {
			request.setAttribute("action","inst");
			RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/client.jsp");
			requestDispatcher.forward(request,response);
		}else if (action.equalsIgnoreCase("setprogram")) {
			String program=request.getParameter("program");
			dao.Setprogram(user,program);
			request.setAttribute("action","");
			RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/client.jsp");
			requestDispatcher.forward(request,response);
		}
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		String afm=(String) request.getAttribute("action");
		
		HttpSession session=request.getSession(false);
		String user=(String) session.getAttribute("username");
		if (action!=null) {
		if (action.equalsIgnoreCase("call")) {
			String caller=request.getParameter("caller");
			String receiver=request.getParameter("receiver");
			String minutes=request.getParameter("minutes");
			String timestamp=request.getParameter("timestamp");
			String answer=dao.Checknumber(receiver,caller);
			
			if (answer=="ok") {
				Call Call=new Call();
				Call.setCaller(caller);
				Call.setReceiver(receiver);
				Call.setMinutes(minutes);
				Call.setTimeStamp(timestamp);
				dao.Addcall(Call);
				List<Call> Calls = new ArrayList<Call>();
				Calls=dao.Showallcalls(caller);
				request.setAttribute("list", Calls);
				request.setAttribute("action","showcalls");
				RequestDispatcher view = request.getRequestDispatcher("/client.jsp");
				view.forward(request, response);
			}else {
				request.setAttribute("answer",answer);
				request.setAttribute("number",caller);
				RequestDispatcher view = request.getRequestDispatcher("/makecall.jsp");
				view.forward(request, response);
			}
		}else if (action.equalsIgnoreCase("afm1")) {
			String answer=dao.Checkafm2(request.getParameter("afm"));
			if (answer=="ok") {
				dao.Insertafm(user,request.getParameter("afm"));
				RequestDispatcher view = request.getRequestDispatcher("/client.jsp");
				view.forward(request, response);
			}else {
				request.setAttribute("answer",answer);
				request.setAttribute("action","afm");
				RequestDispatcher view = request.getRequestDispatcher("/client.jsp");
				view.forward(request, response);
			}
		}
		}
		if (afm=="afm") {
			String answer=dao.Checkafm(user);
			String answer2=dao.Checknumber2(user);
			String answer3=dao.Checkprogram(user);
			if (answer=="You have not entered your afm yet, please enter it.") {
				request.setAttribute("answer",answer);
				request.setAttribute("action","afm");
				RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/client.jsp");
				requestDispatcher.forward(request,response);
			}
			else 
			{
				if (answer2=="A seller has not yet assigned you a number, please log in another time. Thank you for your patience and sorry for the inconvenience.") {
					request.setAttribute("answer",answer2);
					request.setAttribute("action","");
					RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/index.jsp");
					requestDispatcher.forward(request,response);
				}
				else 
				{
					if(answer3=="You have not entered a program yet,please enter it.")
					{
						List<Program> Programs = new ArrayList<Program>();
						Programs=dao.Showallprograms();
						request.setAttribute("list",Programs );
						request.setAttribute("answer",answer3);
						request.setAttribute("action","prog");
						RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/client.jsp");
						requestDispatcher.forward(request,response);
					}
					else 
					{
						request.setAttribute("action", "");
						RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/client.jsp");
						requestDispatcher.forward(request,response);
					}
				}
			}
			
			
			
				
		}
	}
}


