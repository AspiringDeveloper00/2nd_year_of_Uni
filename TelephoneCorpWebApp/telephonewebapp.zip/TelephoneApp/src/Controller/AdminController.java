package Controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DataAccessObject.AdminDao;
import Model.Client;
import Model.Program;
import Model.Seller;


@WebServlet("/admin")
public class AdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private AdminDao dao;
       
    
    public AdminController() {
        super();
        dao=new AdminDao();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		
		if (action.equalsIgnoreCase("deleteseller")) 
		{
			List<Seller> Sellers = new ArrayList<Seller>();
			Sellers=dao.Showallsellers();
			request.setAttribute("list",Sellers );
			request.setAttribute("action","deleteseller");
			RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/admin.jsp");
			requestDispatcher.forward(request,response);
		}
		else if (action.equalsIgnoreCase("delete")) 
		{
			dao.Deleteseller(request.getParameter("username"));
			List<Seller> Sellers = new ArrayList<Seller>();
			Sellers=dao.Showallsellers();
			request.setAttribute("list",Sellers );
			request.setAttribute("action","deleteseller");
			RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/admin.jsp");
			requestDispatcher.forward(request,response);
		}
		else if (action.equalsIgnoreCase("deleteclient")) 
		{
			List<Client> Clients = new ArrayList<Client>();
			Clients=dao.Showclients();
			request.setAttribute("list",Clients );
			request.setAttribute("action","deleteclient");
			RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/admin.jsp");
			requestDispatcher.forward(request,response);
		}
		else if (action.equalsIgnoreCase("delete2")) 
		{
			dao.Deleteclient(request.getParameter("username"),request.getParameter("number"));
			List<Client> Clients = new ArrayList<Client>();
			Clients=dao.Showclients();
			request.setAttribute("list",Clients );
			request.setAttribute("action","deleteclient");
			RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/admin.jsp");
			requestDispatcher.forward(request,response);
		}
		else if (action.equalsIgnoreCase("setemployeeidsalary")) 
		{
			List<Seller> Sellers = new ArrayList<Seller>();
			Sellers=dao.Showsellers();
			request.setAttribute("list",Sellers );
			request.setAttribute("action","setemployeeidsalary");
			RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/admin.jsp");
			requestDispatcher.forward(request,response);
		}
		else if (action.equalsIgnoreCase("set")) 
		{
			Seller Seller= dao.Getsellerbyusername(request.getParameter("username"));
			request.setAttribute("username", Seller.getUsername());
			request.setAttribute("name", Seller.getName());
			request.setAttribute("surname", Seller.getSurname());
			request.setAttribute("employeeid", Seller.getEmployeeId());
			request.setAttribute("salary", Seller.getSalary());
			RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/setidsalary.jsp");
			requestDispatcher.forward(request,response);
		}
		else if (action.equalsIgnoreCase("inst")) 
		{
			request.setAttribute("action","inst");
			RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/admin.jsp");
			requestDispatcher.forward(request,response);
		}
		else if (action.equalsIgnoreCase("newprogram")) 
		{
			RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/newprogram.jsp");
			requestDispatcher.forward(request,response);
		}else if  (action.equalsIgnoreCase("showprograms")) {
			List<Program> Programs = new ArrayList<Program>();
			Programs=dao.Showallprograms();
			request.setAttribute("list",Programs );
			request.setAttribute("action","showprograms");
			RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/admin.jsp");
			requestDispatcher.forward(request,response);
		}
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		
		if (action.equalsIgnoreCase("set")) {
			
			String username=request.getParameter("username");
			String name=request.getParameter("name");
			String surname=request.getParameter("surname");
			String employeeid=request.getParameter("employeeid");
			String salary=request.getParameter("salary");
			

			String answer=dao.Checkemployeeid(employeeid);
			
			if (answer=="ok") {
				Seller Seller=new Seller();
				Seller.setUsername(username);
				Seller.setEmployeeId(employeeid);
				Seller.setSalary(salary);
				dao.Updateseller(Seller);
				List<Seller> Sellers = new ArrayList<Seller>();
				Sellers=dao.Showsellers();
				request.setAttribute("list",Sellers );
				request.setAttribute("action","setemployeeidsalary");
				RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/admin.jsp");
				requestDispatcher.forward(request,response);
				
			}else if (answer=="There is already a seller with that Employee Id."){
				request.setAttribute("answer",answer);
				request.setAttribute("user",username);
				request.setAttribute("name",name);
				request.setAttribute("surname",surname);
				request.setAttribute("employeeid",employeeid);
				request.setAttribute("salary",salary);
				RequestDispatcher view = request.getRequestDispatcher("/setidsalary.jsp");
				view.forward(request, response);
			}
		}else if (action.equalsIgnoreCase("program")){
			String name_program=request.getParameter("program");
			String minutes=request.getParameter("minutes");
			String cost=request.getParameter("cost");
			
			String answer=dao.Checkprogram(name_program);
			
			if (answer=="ok") {
				Program Program=new Program();
				Program.setNameProgram(name_program);
				Program.setMinutesOfTalk(minutes);
				Program.setCost(cost);
				dao.Insertprograms(Program);
				List<Program> Programs = new ArrayList<Program>();
				Programs=dao.Showallprograms();
				request.setAttribute("list",Programs );
				request.setAttribute("action","showprograms");
				RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/admin.jsp");
				requestDispatcher.forward(request,response);
			}else if (answer=="There is already a program with that name.") {
				request.setAttribute("answer", answer);
				RequestDispatcher view = request.getRequestDispatcher("/newprogram.jsp");
				view.forward(request, response);
			}
			
		}
	}

}
